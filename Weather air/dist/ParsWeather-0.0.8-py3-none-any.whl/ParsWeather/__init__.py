from .ParsWeather import WeatherForecast

__version__ = "0.0.8"

__all__ = ["WeatherForecast"]
