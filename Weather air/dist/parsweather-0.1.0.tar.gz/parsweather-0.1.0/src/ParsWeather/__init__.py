from .ParsWeather import WeatherForecast

__version__ = "0.0.10"

__all__ = ["WeatherForecast"]
