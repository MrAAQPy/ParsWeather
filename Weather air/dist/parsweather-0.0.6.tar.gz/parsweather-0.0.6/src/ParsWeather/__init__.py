from .ParsWeather import WeatherForecast

__version__ = "0.0.4"

__all__ = ["WeatherForecast"]
